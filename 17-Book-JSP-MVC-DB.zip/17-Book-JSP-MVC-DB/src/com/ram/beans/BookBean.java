package com.ram.beans;

import java.io.Serializable;

public class BookBean implements Serializable
{
  private String uname;
  private String title;
  private float price;
  private String grade;
public void setuname(String uname) {
	this.uname = uname;
}
public String getuname() {
	return uname;
}
public void setTitle(String title) {
	this.title = title;
}
public String getTitle() {
	return title;
}
public void setPrice(float price) {
	this.price = price;
}
public float getPrice() {
	return price;
}
public void setGrade(String grade) {
	this.grade = grade;
}
public String getGrade() {
	return grade;
}
}
