package com.insurance.claim.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.insurance.claim.bean.ProfileCreation;
import com.insurance.claim.service.ProfileCreationService;

public class ProfileController extends HttpServlet
{
	public  void doGet(HttpServletRequest request,HttpServletResponse response) 
			   throws ServletException,IOException
			{
		
		ProfileCreationService proservice=new ProfileCreationService();
		RequestDispatcher rd = null;
		String user="";
		String pass="";
		String role="";
		String agcode="";
		
		user=request.getParameter("userName");
		pass=request.getParameter("userPwd");
		role=request.getParameter("rolecode");
		agcode=request.getParameter("agentCode");
		int updatecount=proservice.addProfile(user, pass, role,agcode) ;
		System.out.println("inserted "+updatecount+" record   Success");
		
		if (updatecount==1) {
			rd = request.getRequestDispatcher("/profilesuccess.jsp");
		
			
		} else {
			rd = request.getRequestDispatcher("/error.jsp");
		}
		rd.forward(request, response);
}

}
