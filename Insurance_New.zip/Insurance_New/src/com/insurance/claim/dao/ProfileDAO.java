package com.insurance.claim.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.insurance.claim.bean.ProfileCreation;

public class ProfileDAO 
{

	public int addProfile(ProfileCreation probean)
	{
		Connection con = null;
		  PreparedStatement pstmt = null;
		  try {
			  
			  con=DB.getConnection(); 
			  
			  String ins_str ="insert into User_Role values(?,?,?,?)";
			  
			  pstmt = con.prepareStatement(ins_str);
			  
			  pstmt.setString(1,probean.getUsername());
			  pstmt.setString(2,probean.getPassword());
			  pstmt.setString(3,probean.getRolecode());
			  pstmt.setString(4,probean.getAgcode());
			  
			  
			  int updateCount = pstmt.executeUpdate();
			  
			  con.close();
			  
			  return updateCount;
		  }
		  catch(Exception ex)
		  {
			  System.out.println(ex.toString());
			  return 0;
		  }
	
		
	}

}
