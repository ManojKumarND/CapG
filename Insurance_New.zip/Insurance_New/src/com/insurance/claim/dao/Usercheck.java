package com.insurance.claim.dao;

//import java.beans.Statement;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.insurance.claim.Connect;

public class Usercheck extends HttpServlet {
	
	public  void doGet(HttpServletRequest request,HttpServletResponse response) 
			   throws ServletException,IOException
			{
		Connection con=null;
		con=Connect.getconnect();
		
		String str=null;
		RequestDispatcher rd=null;
		
		HttpSession session7=request.getSession(false);
		String agentcode=(String)session7.getAttribute("agcode");
		System.out.println("agcode : "+agentcode);
		ResultSet rs=null;
		try {
		Statement stmt=con.createStatement();
		String custname=request.getParameter("custName");
		System.out.println("custname : "+custname);
		
		HttpSession session8=request.getSession(true);
		 session8.setAttribute("agentcustomer", custname);
		String sqlcom="select Agent_Code from user_role where user_name='"+custname+"'";
		int j=stmt.executeUpdate(sqlcom);
		System.out.println("sqlcom : "+j);
		rs=stmt.executeQuery(sqlcom);
		String code=null;
		while(rs.next())
		 {
			 code=rs.getString(1);
			 System.out.println("code : "+code);
			 
		 }
		if(agentcode.equals(code))
		{
			System.out.println("Present");
		 request.getRequestDispatcher("/createclaim.jsp").include(request, response);
		}
		else
			System.out.println("Sorry! There is no such customer under you!");
		
		
		
		}
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}

	
	
	
}
