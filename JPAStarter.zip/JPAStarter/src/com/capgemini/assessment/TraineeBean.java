package com.capgemini.assessment;
import javax.persistence.Persistence;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Persistence;
import javax.persistence.Persistence;

@Entity
@Table(name="Trainee_Details")

public class TraineeBean {
	
	private static final long serialVersionUID = 1L;
	@Id
	private int details_id;
	
	private String Trainee_name;
	private String Module_name;
	private int mpt_score;
	private int mtt_score;
	private int assignment_marks;
	private int total;
	
	

	public int getTotalMark(int mpt, int mtt, int assign) {
		
		total=((mpt+mtt+assign)/11)*10;
		return total;
		
	}
	
	public int getDetails_id() {
		return details_id;
	}


	public void setDetails_id(int details_id) {
		this.details_id = details_id;
	}

	public String getTrainee_name() {
		return Trainee_name;
	}
	public void setTrainee_name(String trainee_name) {
		Trainee_name = trainee_name;
	}
	public String getModule_name() {
		return Module_name;
	}
	public void setModule_name(String module_name) {
		Module_name = module_name;
	}
	public int getMpt_score() {
		return mpt_score;
	}
	public void setMpt_score(int mpt_score) {
		this.mpt_score = mpt_score;
	}
	public int getMtt_score() {
		return mtt_score;
	}
	public void setMtt_score(int mtt_score) {
		this.mtt_score = mtt_score;
	}
	public int getAssignment_mark() {
		return assignment_marks;
	}
	public void setAssignment_mark(int assignment_marks) {
		this.assignment_marks = assignment_marks;
	}

	public int getTotal() {
		return total;
	}


	public void setTotal(int total) {
		this.total = total;
	}

	
	

}
