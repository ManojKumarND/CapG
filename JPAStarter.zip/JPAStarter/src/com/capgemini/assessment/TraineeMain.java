package com.capgemini.assessment;

import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TraineeMain {

	public static void main(String[] args) {
		
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em = factory.createEntityManager();
	em.getTransaction().begin();
	
	TraineeBean bean=new TraineeBean();
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter Details ID :");
	int id=sc.nextInt();
	bean.setDetails_id(id);
	
	System.out.println("Enter Trainee Name :");
	String name=sc.next();
	bean.setTrainee_name(name);
	
	System.out.println("Enter Module Name :");
	String module=sc.next();
	bean.setModule_name(module);
	
	System.out.println("Enter MPT Score out of 70 :");
	int mpt=sc.nextInt();
	bean.setMpt_score(mpt);
	
	System.out.println("Enter MTT Score out 40 :");
	int mtt=sc.nextInt();
	bean.setMtt_score(mtt);
	
	System.out.println("Enter Assignment mark out of 10 :");
	int assign=sc.nextInt();
	bean.setAssignment_mark(assign);
	
	int total=bean.getTotalMark(mpt,mtt,assign);
	bean.setTotal(total);
	em.persist(bean);
	em.getTransaction().commit();
	
	System.out.println("Successfully added the Trainee to the database!");
	em.close();
	factory.close();
	}
	}
